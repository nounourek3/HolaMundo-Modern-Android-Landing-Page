package com.example.holamundo;
import com.bumptech.glide.Glide;
import eightbitlab.com.blurview.BlurView;
import eightbitlab.com.blurview.RenderScriptBlur;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    //Parte preescrita por defecto
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    //Parte elaborada
        BlurView blurView = findViewById(R.id.blurView);
        View decorView = getWindow().getDecorView();
        ViewGroup rootView = decorView.findViewById(android.R.id.content);

        blurView.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(decorView.getBackground())
                .setBlurRadius(25f)
                .setOverlayColor(Color.parseColor("#30FFFFFF"));
        blurView.setClipToOutline(true);
        blurView.setOutlineProvider(ViewOutlineProvider.BACKGROUND);


        BlurView joinButtonBlur = findViewById(R.id.joinButtonBlur);

        joinButtonBlur.setupWith(rootView, new RenderScriptBlur(this))
                .setFrameClearDrawable(decorView.getBackground())
                .setBlurRadius(15f)
                .setOverlayColor(Color.parseColor("#80FFFFFF"));
        joinButtonBlur.setClipToOutline(true);
        joinButtonBlur.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
    }
}